@extends('master.master')
@section('title', 'Our Team - Jataparking')
@section('content')

<link rel="stylesheet" href="/Assets/css/main/ourteam.css">

<div class="head_ourteam">
    <div class="sub1_head_ourteam">
        <img src="/Assets/Images/line-aboutus.svg" alt="">
        <h1 style="color: #FFFFFF">Our Team</h1>
    </div>
    <div class="sub2_head_ourteam">
        <i class="bi bi-house" style="color: #FFFFFF"></i>
        <p style=" color: #FFFFFF">/</p><p style=" color: #FF8C39;">Our Team</p>
    </div>
</div>

<div class="content_ourteam">
    <div class="img_team">
        <img src="" alt="">
    </div>
    <div class="img_team">
        <img src="" alt="">
    </div>
    <div class="img_team">
        <img src="" alt="">
    </div>
</div>

@endsection